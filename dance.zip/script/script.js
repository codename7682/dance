$(document).ready(function(){
    

    function rand(min,max){
        var result = parseInt(Math.floor(Math.random()*(max-min))+min);
        return result;
    }
    var dan;
    var score = 0;
    function dance(){
        var term = rand(20,120);
        dan = setTimeout(function(){
            var old = $("#student").attr("src");
            if(old == "images/d1.png"){
                $("#student").attr("src","images/d2.png");
            }else{
                $("#student").attr("src","images/d1.png");
            }
            dance();
        },term);
        score++;
        $("#score").text(score);
    }

    var music = document.getElementById("music");
    
    

    var termz = rand(1000,2000);
    setTimeout(turn,termz);
    var teaching = true;
    function turn(){
        var teacher = $("#teacher");
        
        var term0 = rand(500,5000); // 수업하는 시간
        var term1 = rand(100,200);
        var term2 = rand(100,200);
        var term3 = rand(300,4000); //바라보는 시간
        setTimeout(function(){
            teacher.attr("src","images/t2.png");
            setTimeout(function(){
                teacher.attr("src","images/t3.png");
                teaching = false;
                setTimeout(function(){
                    teacher.attr("src","images/t2.png");
                    setTimeout(function(){
                        teacher.attr("src","images/t1.png");
                        teaching = true;
                        setTimeout(turn,term0);
                    },term2);
                },term3);
            },term2);
        },term1);
    }
    
    function gameover(){
        $("#over").show();
        $("#final").text("최종점수 : "+score);
    }
    
    
    
    $(document).keypress(function(e){
        var old = $("#student").attr("src");
        music.play();
        if(e.keyCode == 32 && old == "images/d0.png") {
            dance();
        }
        if(!teaching){
            setTimeout(dan);
            gameover();
        }
    });
    
    $(document).keyup(function(e){
        clearTimeout(dan);
        music.pause();
        music.currentTime = 0;
        $("#student").attr("src","images/d0.png");
    });
    
});












